//*******************************************************
//
//               Delphi DataSnap Framework
//
// Copyright(c) 1995-2011 Embarcadero Technologies, Inc.
//
//*******************************************************

namespace Embarcadero.Datasnap.WindowsPhone7
{
    /**
     * 
     * used to label the types that should be managed as a table
     *
     */
    public interface TableType
    {
    }
}
